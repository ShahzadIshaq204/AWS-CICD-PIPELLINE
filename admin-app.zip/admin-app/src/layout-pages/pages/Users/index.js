import React from "react";
import UsersHistory from "./components/UsersHistory";

export default function index() {
  return <UsersHistory />;
}

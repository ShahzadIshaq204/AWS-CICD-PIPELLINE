import React from "react";
import SessionsHistory from "./components/SessionsHistory";

export default function index() {
  return <SessionsHistory />;
}

import usFlag from "../../assets/images/flags/us.jpg";
import frFlag from "../../assets/images/flags/french.jpg";

const languages = {
  // en: {
  //   label: "English",
  //   flag: usFlag,
  // },
  fr: {
    // todo change to en
    flag: usFlag,
    label: "English",
  },
};

export default languages;

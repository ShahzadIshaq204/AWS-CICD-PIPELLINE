// const DEFAULT_COLOR = "#ffff";

// // transactions type
// export const TRANSACTION_CASH_IN = "CASH_IN";
// export const TRANSACTION_CASH_OUT = "CASH_OUT";
// export const TRANSACTION_TRANSFERT = "TRANSFERT";
// export const TRANSACTION_PAY = "PAY";

// export const TRANSACTION_TYPE_MAPPER = {
//   CASH_IN: {
//     label: "page.common.enum.transactionStatus.cashin",
//     backgroundColor: "primary",
//     //color: DEFAULT_COLOR,
//   },
//   CASH_OUT: {
//     label: "page.common.enum.transactionStatus.cashout", //"Cash out",
//     backgroundColor: "danger",
//     //color: DEFAULT_COLOR,
//   },
//   TRANSFERT: {
//     label: "page.common.enum.transactionStatus.transfert", //"Transfert",
//     backgroundColor: "warning",
//     //color: DEFAULT_COLOR,
//   },
//   PAY: {
//     label: "page.common.enum.transactionStatus.pay", //"Paiement",
//     backgroundColor: "success",
//     //color: DEFAULT_COLOR,
//   },
// };

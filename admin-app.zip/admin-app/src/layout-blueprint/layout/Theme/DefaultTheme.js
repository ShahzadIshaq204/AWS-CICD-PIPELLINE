import React from "react";
import "../../../assets/scss/theme.scss";
import { log } from "utils/helpers/environment";
const DefaultTheme = () => <React.Fragment>{log("default")}</React.Fragment>;
export default DefaultTheme;
